<?php
/*
Plugin Name: SecureSite Toolkit
Description: A security plugin with login tracking, email notifications, page password protection, anti-copy, and image watermarking.
Version: 1.0
Author: Webloop
License: GPL2
*/

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Create database table for login attempts on activation
function sst_create_tables() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sst_login_attempts';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        username varchar(255) NOT NULL,
        ip_address varchar(100) NOT NULL,
        attempt_time datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'sst_create_tables');

// Add settings page
function sst_admin_menu() {
    add_menu_page(
        'SecureSite Toolkit',
        'Security Toolkit',
        'manage_options',
        'sst-settings',
        'sst_settings_page',
        'dashicons-shield',
        94
    );
    add_submenu_page(
        'sst-settings',
        'Login Attempts',
        'View Login Attempts',
        'manage_options',
        'sst-login-attempts',
        'sst_view_login_attempts_page'
    );
}
add_action('admin_menu', 'sst_admin_menu');

// Register settings
function sst_register_settings() {
    // Login Attempt Tracker
    register_setting('sst_settings_group', 'sst_enable_login_tracker', ['sanitize_callback' => 'absint']);
    // Email Login Notifier
    register_setting('sst_settings_group', 'sst_enable_email_notifier', ['sanitize_callback' => 'absint']);
    register_setting('sst_settings_group', 'sst_notifier_email', ['sanitize_callback' => 'sanitize_email']);
    // Page Password Protector
    register_setting('sst_settings_group', 'sst_enable_page_protector', ['sanitize_callback' => 'absint']);
    // Simple Anti-Copy
    register_setting('sst_settings_group', 'sst_enable_anti_copy', ['sanitize_callback' => 'absint']);
    // Image Theft Guard
    register_setting('sst_settings_group', 'sst_enable_watermark', ['sanitize_callback' => 'absint']);
    register_setting('sst_settings_group', 'sst_watermark_text', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('sst_settings_group', 'sst_watermark_opacity', ['sanitize_callback' => 'floatval']);
}
add_action('admin_init', 'sst_register_settings');

// Settings page
function sst_settings_page() {
    ?>
    <div class="wrap">
        <h1>SecureSite Toolkit</h1>
        <p>Configure security features to protect your WordPress site.</p>
        <form method="post" action="options.php">
            <?php settings_fields('sst_settings_group'); ?>
            <?php do_settings_sections('sst_settings_group'); ?>
            <h2>Login Attempt Tracker</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sst_enable_login_tracker">Enable Login Tracker</label></th>
                    <td>
                        <input type="checkbox" id="sst_enable_login_tracker" name="sst_enable_login_tracker" value="1" <?php checked(get_option('sst_enable_login_tracker', 1)); ?> />
                        <p class="description">Track failed login attempts and view them in "View Login Attempts".</p>
                    </td>
                </tr>
            </table>
            <h2>Email Login Notifier</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sst_enable_email_notifier">Enable Email Notifier</label></th>
                    <td>
                        <input type="checkbox" id="sst_enable_email_notifier" name="sst_enable_email_notifier" value="1" <?php checked(get_option('sst_enable_email_notifier', 1)); ?> />
                        <p class="description">Send email notifications for logins from new devices/IPs.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sst_notifier_email">Notification Email</label></th>
                    <td>
                        <input type="email" id="sst_notifier_email" name="sst_notifier_email" value="<?php echo esc_attr(get_option('sst_notifier_email', get_option('admin_email'))); ?>" class="regular-text" />
                        <p class="description">Email address to receive login notifications.</p>
                    </td>
                </tr>
            </table>
            <h2>Page Password Protector</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sst_enable_page_protector">Enable Page Protector</label></th>
                    <td>
                        <input type="checkbox" id="sst_enable_page_protector" name="sst_enable_page_protector" value="1" <?php checked(get_option('sst_enable_page_protector', 1)); ?> />
                        <p class="description">Add password protection to pages/posts via a meta box.</p>
                    </td>
                </tr>
            </table>
            <h2>Simple Anti-Copy</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sst_enable_anti_copy">Enable Anti-Copy</label></th>
                    <td>
                        <input type="checkbox" id="sst_enable_anti_copy" name="sst_enable_anti_copy" value="1" <?php checked(get_option('sst_enable_anti_copy', 1)); ?> />
                        <p class="description">Disable right-click and text selection on the front-end.</p>
                    </td>
                </tr>
            </table>
            <h2>Image Theft Guard</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="sst_enable_watermark">Enable Watermarking</label></th>
                    <td>
                        <input type="checkbox" id="sst_enable_watermark" name="sst_enable_watermark" value="1" <?php checked(get_option('sst_enable_watermark', 1)); ?> />
                        <p class="description">Automatically watermark images on upload.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sst_watermark_text">Watermark Text</label></th>
                    <td>
                        <input type="text" id="sst_watermark_text" name="sst_watermark_text" value="<?php echo esc_attr(get_option('sst_watermark_text', get_bloginfo('name'))); ?>" class="regular-text" />
                        <p class="description">Text to display as watermark (e.g., site name or copyright).</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sst_watermark_opacity">Watermark Opacity</label></th>
                    <td>
                        <input type="number" id="sst_watermark_opacity" name="sst_watermark_opacity" value="<?php echo esc_attr(get_option('sst_watermark_opacity', 0.5)); ?>" min="0" max="1" step="0.1" />
                        <p class="description">Opacity of the watermark (0 to 1, default: 0.5).</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <h2>How It Works</h2>
        <ul>
            <li><strong>Login Attempt Tracker</strong>: Logs failed login attempts and displays them in "View Login Attempts".</li>
            <li><strong>Email Login Notifier</strong>: Emails the specified address when a user logs in from a new device/IP.</li>
            <li><strong>Page Password Protector</strong>: Adds a password field to page/post edit screens for protection.</li>
            <li><strong>Simple Anti-Copy</strong>: Disables right-click and text selection to deter content copying.</li>
            <li><strong>Image Theft Guard</strong>: Adds a watermark to images on upload to prevent theft.</li>
        </ul>
        <p><strong>Note:</strong> Ensure your server supports PHP GD for watermarking and email sending. Test email delivery with a plugin like “Check & Log Email”. Use an SMTP plugin (e.g., WP Mail SMTP) for reliable emails. Back up your site before enabling features.</p>
    </div>
    <?php
}

// View login attempts
function sst_view_login_attempts_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sst_login_attempts';
    $attempts = $wpdb->get_results("SELECT * FROM $table_name ORDER BY attempt_time DESC LIMIT 100");
    ?>
    <div class="wrap">
        <h1>Failed Login Attempts</h1>
        <p>Recent failed login attempts (up to 100).</p>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>IP Address</th>
                    <th>Attempt Time</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($attempts) : ?>
                    <?php foreach ($attempts as $attempt) : ?>
                        <tr>
                            <td><?php echo esc_html($attempt->username); ?></td>
                            <td><?php echo esc_html($attempt->ip_address); ?></td>
                            <td><?php echo esc_html($attempt->attempt_time); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="3">No failed login attempts recorded.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <p><strong>Note:</strong> Failed attempts are stored in the database. Use a database tool to export or clear old records.</p>
    </div>
    <?php
}

// Login Attempt Tracker
function sst_track_failed_login($username) {
    if (!get_option('sst_enable_login_tracker', 1)) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'sst_login_attempts';
    $ip_address = $_SERVER['REMOTE_ADDR'];

    $wpdb->insert(
        $table_name,
        [
            'username' => sanitize_text_field($username),
            'ip_address' => sanitize_text_field($ip_address),
        ],
        ['%s', '%s']
    );
}
add_action('wp_login_failed', 'sst_track_failed_login');

// Email Login Notifier
function sst_notify_new_login($user_login, $user) {
    if (!get_option('sst_enable_email_notifier', 1)) {
        return;
    }

    $notifier_email = get_option('sst_notifier_email', get_option('admin_email'));
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_id = $user->ID;
    $last_ip = get_user_meta($user_id, 'sst_last_login_ip', true);

    if ($last_ip !== $ip_address) {
        update_user_meta($user_id, 'sst_last_login_ip', $ip_address);
        $subject = 'New Login Detected on ' . get_bloginfo('name');
        $content = wpautop("Hello,\n\nA new login was detected for user: $user_login\nIP Address: $ip_address\nTime: " . current_time('mysql') . "\n\nIf this was not you, please secure your account immediately.\n\nBest regards,\n" . get_bloginfo('name') . " Team");
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>',
        ];
        $result = wp_mail($notifier_email, $subject, $content, $headers);
        if (!$result) {
            error_log('SecureSite Toolkit: Failed to send login notification to ' . $notifier_email);
        }
    }
}
add_action('wp_login', 'sst_notify_new_login', 10, 2);

// Page Password Protector
function sst_add_password_meta_box() {
    if (!get_option('sst_enable_page_protector', 1)) {
        return;
    }

    add_meta_box(
        'sst_page_password',
        'Page Password Protection',
        'sst_page_password_meta_box_callback',
        ['page', 'post'],
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'sst_add_password_meta_box');

function sst_page_password_meta_box_callback($post) {
    wp_nonce_field('sst_save_page_password', 'sst_page_password_nonce');
    $password = get_post_meta($post->ID, '_sst_page_password', true);
    ?>
    <p>
        <label for="sst_page_password">Password:</label><br>
        f<input type="text" id="sst_page_password" name="sst_page_password" value="<?php echo esc_attr($password); ?>" class="widefat" />
    </p>
    <p class="description">Enter a password to protect this page/post. Leave blank to disable.</p>
    <?php
}

function sst_save_page_password($post_id) {
    if (!isset($_POST['sst_page_password_nonce']) || !wp_verify_nonce($_POST['sst_page_password_nonce'], 'sst_save_page_password')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $password = isset($_POST['sst_page_password']) ? sanitize_text_field($_POST['sst_page_password']) : '';
    update_post_meta($post_id, '_sst_page_password', $password);
}
add_action('save_post', 'sst_save_page_password');

function sst_protect_page_content($content) {
    if (!get_option('sst_enable_page_protector', 1) || is_admin() || !is_singular()) {
        return $content;
    }

    global $post;
    $password = get_post_meta($post->ID, '_sst_page_password', true);
    if (empty($password)) {
        return $content;
    }

    if (isset($_POST['sst_page_password']) && $_POST['sst_page_password'] === $password) {
        setcookie('sst_page_access_' . $post->ID, $password, time() + 3600, '/');
        return $content;
    }

    if (isset($_COOKIE['sst_page_access_' . $post->ID]) && $_COOKIE['sst_page_access_' . $post->ID] === $password) {
        return $content;
    }

    ob_start();
    ?>
    <form method="post" class="sst-password-form">
        <p><label for="sst_page_password">Enter Password:</label></p>
        <p><input type="password" id="sst_page_password" name="sst_page_password" required /></p>
        <p><input type="submit" value="Submit" class="button" /></p>
    </form>
    <style>
        .sst-password-form { text-align: center; margin: 50px auto; max-width: 300px; }
        .sst-password-form input[type="password"] { width: 100%; padding: 10px; margin-bottom: 10px; }
        .sst-password-form input[type="submit"] { padding: 10px 20px; background: #0073aa; color: #fff; border: none; cursor: pointer; }
        .sst-password-form input[type="submit"]:hover { background: #005f8c; }
    </style>
    <?php
    return ob_get_clean();
}
add_filter('the_content', 'sst_protect_page_content');

// Simple Anti-Copy
function sst_enqueue_anti_copy_script() {
    if (!get_option('sst_enable_anti_copy', 1)) {
        return;
    }

    wp_enqueue_script('sst-anti-copy', plugin_dir_url(__FILE__) . 'sst-anti-copy.js', [], '1.0', true);
    wp_enqueue_style('sst-anti-copy', plugin_dir_url(__FILE__) . 'sst-anti-copy.css', [], '1.0');
}
add_action('wp_enqueue_scripts', 'sst_enqueue_anti_copy_script');

function sst_create_anti_copy_js() {
    $js_content = <<<JS
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});
document.addEventListener('copy', function(e) {
    e.preventDefault();
});
document.addEventListener('cut', function(e) {
    e.preventDefault();
});
JS;
    file_put_contents(plugin_dir_path(__FILE__) . 'sst-anti-copy.js', $js_content);
}
register_activation_hook(__FILE__, 'sst_create_anti_copy_js');

function sst_create_anti_copy_css() {
    $css_content = <<<CSS
body {
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
CSS;
    file_put_contents(plugin_dir_path(__FILE__) . 'sst-anti-copy.css', $css_content);
}
register_activation_hook(__FILE__, 'sst_create_anti_copy_css');

// Image Theft Guard
function sst_watermark_image($attachment_id) {
    if (!get_option('sst_enable_watermark', 1)) {
        return;
    }

    if (!function_exists('imagecreatefromjpeg')) {
        error_log('SecureSite Toolkit: PHP GD library is not available for watermarking.');
        return;
    }

    $image_path = get_attached_file($attachment_id);
    $image_type = wp_check_filetype($image_path)['ext'];
    if (!in_array(strtolower($image_type), ['jpg', 'jpeg', 'png'])) {
        return;
    }

    $watermark_text = get_option('sst_watermark_text', get_bloginfo('name'));
    $opacity = min(max(floatval(get_option('sst_watermark_opacity', 0.5)), 0), 1) * 100;

    // Load image
    if (strtolower($image_type) === 'png') {
        $image = imagecreatefrompng($image_path);
    } else {
        $image = imagecreatefromjpeg($image_path);
    }

    if (!$image) {
        error_log('SecureSite Toolkit: Failed to load image for watermarking: ' . $image_path);
        return;
    }

    // Create watermark
    $text_color = imagecolorallocatealpha($image, 255, 255, 255, (1 - $opacity / 100) * 127);
    $font = ABSPATH . 'wp-includes/fonts/arial.ttf'; // Fallback to a common font
    if (!file_exists($font)) {
        $font = null; // Use default font if not available
    }

    $image_width = imagesx($image);
    $image_height = imagesy($image);
    $font_size = $image_width / 20; // Dynamic font size
    $text_box = imagettfbbox($font_size, 0, $font ?: null, $watermark_text);
    $text_width = $text_box[2] - $text_box[0];
    $text_height = $text_box[1] - $text_box[7];
    $x = ($image_width - $text_width) / 2;
    $y = ($image_height + $text_height) / 2;

    if ($font) {
        imagettftext($image, $font_size, 0, $x, $y, $text_color, $font, $watermark_text);
    } else {
        imagestring($image, 5, $x, $y, $watermark_text, $text_color);
    }

    // Save image
    if (strtolower($image_type) === 'png') {
        imagepng($image, $image_path, 9);
    } else {
        imagejpeg($image, $image_path, 90);
    }

    imagedestroy($image);
}
add_action('add_attachment', 'sst_watermark_image');
?>